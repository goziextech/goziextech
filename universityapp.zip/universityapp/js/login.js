$(document).ready(function(){login()});function login(){var url="http://recruitment.studyinbudapest.comuniversities"
$.ajax({url:url,method:"GET",headers:{"Accept":"application/json; odata=verbose"},success:function(data){console.log(data)
var entereduseremail="country";var setemailtolowercase=entereduseremail.toLowerCase()
$.each(data,function(key,value){if((value.email)=="naila@studyinbudapest.com"){alert(" Found it")
return!1}else{alert(" didn't find it")}})},error:function(data){console.log(data)
alert("Oops, something went wrong,Could not retrieve data from server,please check your internet connection and try again")}})}