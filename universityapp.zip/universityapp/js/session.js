$(document).ready(function(){

var timer = null;

function resetSession() {
    clearTimeout(timer);
    timer = setTimeout(function() {
        window.location = 'university-login.html';
    }, 5000);
}

window.addEventListener('mousemove', resetSession, true);

resetSession();

});