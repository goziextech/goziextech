    var mongoose = require ('mongoose');
    var bcrypt = require('bcryptjs');
    //Universities Schema
    var universitiesSchema = mongoose.Schema({

        first_name: { type: String, 
                      required: true
                    },
        last_name: { type: String, 
                      required: true
                    },
        email: { type: String, 
                      required: true
                    },
        username: { type: String, 
                      required: false
                    },
        password: { type: String, 
                      required: false
                    },
        pd: { type: String, 
                      required: false
                    },
        sub_date: { type: String, 
                      required: false
                    },
        number_of_students: { type: Number, 
                      required: false
                    },
        notification_badge: { type: String, 
                      required: false
                    },
        trial: { type: Boolean, 
                      required: false
                    },
        device: { type: String, 
                      required: false
                    },
        about: { type: String, 
                      required: false
                    },
        session: { type: String, 
                      required: false //Check false and False for fields that are not required
                    },
        activation: { type: String, 
                      required: false //Check false and False for fields that are not required
                    },
        role: { type: String, 
                      required: false //Check false and False for fields that are not required
                    },
        msg_txt : [{

        message: { type: String, 
                      required: false 
                    },
        date_of_activity: { type: String, 
                      required: false 
                    },    
        create_date:{
            type: Date,
            default: Date.now
        }
            }],
        date_of_activity: { type: String, 
                      required: false
                    },
        university: { type: String, 
                      required: false
                    },
        country: { type: String, 
                      required: false
                    },
        city: { type: String, 
                      required: false
                    },
        state: { type: String, 
                      required: false
                    },
        phone: { type: String, 
                      required: false
                    },
        courses : [{

        course_name: { type: String, 
                      required: false
                    },
        about_course: { type: String, 
                      required: false
                    },
        tuition: { type: String, 
                      required: false
                    },
        application_fee: { type: String, 
                      required: false
                    },
        application_requirement: { type: String, 
                      required: false
                    },
        application_deadline: { type: String, 
                      required: false
                    },
        create_date:{
            type: Date,
            default: Date.now
        }
            }],
        admission_offers : [{

        first_name: { type: String, 
                      required: true
                    },
        last_name: { type: String, 
                      required: true
                    },
        student_id:{ type: String, 
                      required: true
                    },    
        email: { type: String, 
                      required: true
                    },
        university: { type: String, 
                      required: true
                    },
        country: { type: String, 
                      required: true
                    },
        phone: { type: String, 
                      required: false
                    },
        course: { type: String, 
                      required: false
                    },
        application_status: { type: String, 
                      required: true
                    },
        live_status: { type: String, 
                      required: false
                    },
        academic_qualification: { type: String, 
                      required: false
                    },
        language_proficiency: { type: String, 
                      required: false
                    },
        travel_visa: { type: String, 
                      required: false
                    },
        date_of_activity: { type: String, 
                      required: false
                    },    
        create_date:{
            type: Date,
            default: Date.now
        }
            }],
        rejected_students : [{

        first_name: { type: String, 
                      required: true
                    },
        last_name: { type: String, 
                      required: true
                    },
        email: { type: String, 
                      required: true
                    },  
        university: { type: String, 
                      required: true
                    },
        country: { type: String, 
                      required: true
                    },
        phone: { type: String, 
                      required: true
                    },
        course: { type: String, 
                      required: false
                    },
        application_status: { type: String, 
                      required: false
                    },
        live_status: { type: String, 
                      required: false
                    },
        academic_qualification: { type: String, 
                      required: false
                    },
        language_proficiency: { type: String, 
                      required: false
                    },
        travel_visa: { type: String, 
                      required: false
                    },
        date_of_activity: { type: String, 
                      required: false
                    },    
        create_date:{
            type: Date,
            default: Date.now
        }
            }],
        verification_status : { type: String, 
                      required: false
                    },
        notification : { type: String, 
                      required: false
                    },
        processed_students: [{

        first_name: { type: String, 
                      required: true
                    },
        last_name: { type: String, 
                      required: true
                    },
        student_id:{ type: String, 
                      required: true
                    },     
        email: { type: String, 
                      required: true
                    },  
        university: { type: String, 
                      required: true
                    },
        country: { type: String, 
                      required: true
                    },
        phone: { type: String, 
                      required: true
                    },
        course: { type: String, 
                      required: false
                    },
        application_status: { type: String, 
                      required: false
                    },
        live_status: { type: String, 
                      required: false
                    },
        academic_qualification: { type: String, 
                      required: false
                    },
        language_proficiency: { type: String, 
                      required: false
                    },
        travel_visa: { type: String, 
                      required: false
                    },
        date_of_activity: { type: String, 
                      required: false
                    },    
        create_date:{
            type: Date,
            default: Date.now
        }
            }],
        image_url : { type: String, 
                      required: false
                    },
        university_website : { type: String, 
                      required: false
                    },
        application_portal : { type: String, 
                      required: false
                    },
        create_date:{
            type: Date,
            default: Date.now
        }

    });

    //Module.export mongoose model for Universities collection using universitiesSchema
    var Universities = module.exports = mongoose.model('Universities',universitiesSchema);


    // Get Universities
    module.exports.getUniversities = function(callback,limit){
    Universities.find(callback).limit(limit);    

    }

    // Get Universities by ID
    module.exports.getUniversitiesById = function(id, callback){
    var _id = id;    
    Universities.findById(_id, callback);    

    }

    // Get Recruited Student by ID
    module.exports.getRecruitedStudentById = function(id, callback){
    //var _id = {"admission_offers._id":id} 
    var _id = id;     
    Universities.findById(_id, callback);    

    }

    //Add New university
    module.exports.addUniversity = function(university,callback){

    /*bcrypt.genSalt(10, function(err, salt){
      bcrypt.hash(university.password, salt, function(err,hash){
       university.password = hash;
       university.save(callback);// can replace university.create
      }); //end gensalt   
    });//end hash*/

    Universities.create(university, callback);

    }
    
    //Bcryptjs Compare
    /*module.exports.comparePassword = function(candidatePassword, hash , callback){

    bcrypt.compare(candidatePassword, hash, function(err, isMatch){
    if (err) throw err;
    callback(null, isMatch)
    });//end compare

    }*/

    /*// Deactivate trial by Node timeout on registration
    module.exports.deactivateTrial = function(createduniversity, options, callback){
    var id = {_id: createduniversity._id};
     var update = { 
        $set: {
        trial : false

            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }*/
    
    
     //Update Number of Students 
    module.exports.updateNumberOfStudents = function(universityid, numberofappliedstudents, options, callback){
    var id = {_id: universityid}; //Mongodb sytax
     var update = { 
        $set: {
        number_of_students : numberofappliedstudents
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }
    
       //Update Number of Students after a student has been deleted 
    module.exports.reduceNumberOfStudentCount = function(uid, newNumberOfStudentCount, options, callback){
    var id = {_id: uid};
     var update = { 
        $set: {
        number_of_students : newNumberOfStudentCount
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }
    
    //Turn on Email Notifications 
    module.exports.turnOnNotifications = function(universityid,options, callback){
    var id = {_id: universityid}; //Mongodb sytax
     var update = { 
        $set: {
        notification : "on"
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }
    
   
    //Turn off Email Notifications 
    module.exports.turnOffNotifications = function(uid, options, callback){
    var id = {_id: uid}; //Mongodb sytax
     var update = { 
        $set: {
        notification : "off"
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }


    //  Edit University First Name
    module.exports.EditUniversityFirstName = function(id, universityfirstname, options, callback){
    var id = {_id: id}; //Mongodb sytax
     var update = { 
        $set: {
        first_name : universityfirstname
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }
    
    //Edit University Last Name 
    module.exports.EditUniversityLastName = function(id, universitylastname, options, callback){
    var id = {_id: id}; //Mongodb sytax
     var update = { 
        $set: {
        last_name : universitylastname
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }
    

    // Edit University Email
    module.exports.EditUniversityEmail = function(id, universityemail, options, callback){
    var id = {_id: id}; //Mongodb sytax
     var update = { 
        $set: {
        email : universityemail,
        username: universityemail    
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }

    // Edit University Password
    module.exports.EditUniversityPassword = function(id, password, options, callback){
    var id = {_id: id}; //Mongodb sytax
     var update = { 
        $set: {
        password : password
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }

    // Edit University phone
    module.exports.EditUniversityPhone = function(id, phonenumber, options, callback){
    var id = {_id: id}; //Mongodb sytax
     var update = { 
        $set: {
        phone : phonenumber
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }
    
    
    // Edit  University Email and Phone
    module.exports.EditUniversityEmailPhone = function(id, universityemail,phonenumber, options, callback){
    var id = {_id: id}; //Mongodb sytax
     var update = { 
        $set: {
        phone : phonenumber,
        email: universityemail,
        username: universityemail   
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }                                            

     //  Edit University Email and  Password
    module.exports.EditUniversityEmailPassword = function(id, password, universityemail, options, callback){
    var id = {_id: id}; //Mongodb sytax
     var update = { 
        $set: {
        password : password,
        email: universityemail,
        username: universityemail    
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }
    
    // Edit University First Name and Email
    module.exports.EditUniversityFirstNameEmail = function(id, universityfirstname,universityemail, options, callback){
    var id = {_id: id}; //Mongodb sytax
     var update = { 
        $set: {
        first_name : universityfirstname,
        email: universityemail,
        username: universityemail    
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }
    
    //Edit University Password Phone  
    module.exports.EditUniversityPasswordPhone = function(id, password, phonenumber, options, callback){
    var id = {_id: id}; //Mongodb sytax
     var update = { 
        $set: {
        password : password,
        phone: phonenumber    
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }
    
    //Edit University Firstname and Password  
    module.exports.EditUniversityFullnamePassword = function(id, universityfirstname, password, options, callback){
    var id = {_id: id}; //Mongodb sytax
     var update = { 
        $set: {
        password : password,
        first_name: universityfirstname    
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }

    //Edit University Firstname and Password  
    module.exports.EditUniversityFirstnameLastnamePassword = function(id, universityfirstname,universitylastname, password, options, callback){
        var id = {_id: id}; //Mongodb sytax
         var update = { 
            $set: {
            password : password,
            first_name: universityfirstname,
            last_name: universitylastname    
                }//End Set          
            } //End Update    
         Universities.findOneAndUpdate(id, update, options, callback); 
    
        }
    
    //Edit University Phone and Fullname  
    module.exports.EditUniversityPhoneFullname = function(id, universityfirstname, phonenumber, options, callback){
    var id = {_id: id}; //Mongodb sytax
     var update = { 
        $set: {
        phone : phonenumber,
        first_name: universityfirstname    
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }
    
    //Edit University LastName and FullName  
    module.exports.EditUniversityLastNameFullName = function(id, universityfirstname, universitylastname, options, callback){
    var id = {_id: id}; //Mongodb sytax
     var update = { 
        $set: {
        last_name : universitylastname,
        first_name: universityfirstname    
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }
    
    //Edit University LastName and Password  
    module.exports.EditUniversityLastNamePassword = function(id, universitylastname, password, options, callback){
    var id = {_id: id}; //Mongodb sytax
     var update = { 
        $set: {
        last_name : universitylastname,
        password: password    
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }
    
    //Edit University LastName and Email  
    module.exports.EditUniversityLastNameEmail = function(id, universitylastname, universityemail, options, callback){
    var id = {_id: id}; //Mongodb sytax
     var update = { 
        $set: {
        last_name : universitylastname,
        email: universityemail,
        username:universityemail    
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }
    
    //Edit University LastName and PhoneNumber  
    module.exports.EditUniversityLastNamePhoneNumber = function(id, universitylastname, phonenumber, options, callback){
    var id = {_id: id}; //Mongodb sytax
     var update = { 
        $set: {
        last_name : universitylastname,
        phone: phonenumber   
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }
    
    //Edit University LastName and PhoneNumber  
    module.exports.EditAllUniversityDetail = function(id,universityfirstname, universitylastname, universityemail, password, phonenumber, applicationportal, options, callback){
    var id = {_id: id}; //Mongodb sytax
     var update = { 
        $set: {
        first_name: universityfirstname,    
        last_name : universitylastname,
        email:universityemail,
        username:universityemail,    
        password:password,    
        phone: phonenumber,
        application_portal: applicationportal   
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }
    
    //Edit University FirstName and Application Portal  
    module.exports.EditFirstNameApplicationPortal = function(id,universityfirstname, applicationportal, options, callback){
    var id = {_id: id}; //Mongodb sytax
     var update = { 
        $set: {
        first_name: universityfirstname,    
        application_portal: applicationportal   
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }
    
     //Edit University LastName and Application Portal  
    module.exports.EditLastNameApplicationPortal = function(id,universitylastname, applicationportal, options, callback){
    var id = {_id: id}; //Mongodb sytax
     var update = { 
        $set: {
        last_name: universitylastname,    
        application_portal: applicationportal   
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }
    
      //Edit University Email Application Portal 
    module.exports.EditEmailApplicationPortal = function(id, universityemail, applicationportal, options, callback){
    var id = {_id: id}; //Mongodb sytax
     var update = { 
        $set: {    
        application_portal: applicationportal,
        email:universityemail,
        username:universityemail    
        
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }
    
      //Edit University Password Application Portal
    module.exports.EditPasswordApplicationPortal = function(id, password, applicationportal, options, callback){
    var id = {_id: id}; //Mongodb sytax
     var update = { 
        $set: {    
        application_portal: applicationportal,
        password:password    
        
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }
    
    //Edit University Phone Application Portal
    module.exports.EditPhoneApplicationPortal = function(id, phonenumber, applicationportal, options, callback){
    var id = {_id: id}; //Mongodb sytax
     var update = { 
        $set: {    
        application_portal: applicationportal,
        phone: phonenumber    
        
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }
    
    //Edit First Name, Last Name,Email and Application Portal
    module.exports.EditFirstNameLastNameEmailApplicationPortal = function(id,universityfirstname, universitylastname, universityemail, applicationportal, options, callback){
    var id = {_id: id}; //Mongodb sytax
     var update = { 
        $set: { 
        first_name: universityfirstname,
        last_name: universitylastname,     
        email:universityemail,
        username:universityemail,    
        application_portal: applicationportal,
           
        
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }
    
    //Edit Last Name,Email and Application Portal
    module.exports.EditLastNameEmailApplicationPortal = function(id, universitylastname, universityemail, applicationportal, options, callback){
    var id = {_id: id}; //Mongodb sytax
     var update = { 
        $set: { 
        last_name: universitylastname,     
        email:universityemail,
        username:universityemail,    
        application_portal: applicationportal,
           
        
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }
    
    //Edit Application Portal, Password and Phone
    module.exports.EditApplicationPortalPasswordPhone = function(id, applicationportal, password, phonenumber, options, callback){
    var id = {_id: id}; //Mongodb sytax
     var update = { 
        $set: {     
        application_portal: applicationportal,
        password: password,     
        phone:phonenumber
          
        
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }
    
    //Edit University First name, LastName and PhoneNumber  
    module.exports.EditFirstNameLastNameEmail = function(id,universityfirstname, universitylastname, universityemail, options, callback){
    var id = {_id: id}; //Mongodb sytax
     var update = { 
        $set: {
        first_name: universityfirstname,    
        last_name : universitylastname,
        email:universityemail,
        username:universityemail    
        
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }
    
    //Edit University First Name LastName and PhoneNumber  
    module.exports.EditFirstNameLastNameEmailPassword = function(id,universityfirstname, universitylastname, universityemail,password, options, callback){
    var id = {_id: id}; //Mongodb sytax
     var update = { 
        $set: {
        first_name: universityfirstname,    
        last_name : universitylastname,
        email:universityemail,
        username:universityemail,
        password:password    
        
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }
    
    //Edit University Application Portal  
    module.exports.EditUniversityApplicationPortal = function(id,applicationportal, options, callback){
    var id = {_id: id}; //Mongodb sytax
     var update = { 
        $set: {
        application_portal: applicationportal,
        verification_status:"no"    
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }
    
    
    
    
    // Deactivate trial
    module.exports.deactivateTrialPeriod = function(id, options, callback){
    var id = {_id: id};
     var update = { 
        $set: {
        trial : false,
        pd:"free" //Set it back to free    

            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }

      // Deactivate Subscription
    module.exports.resetSubscription = function(id, options, callback){
    var id = {_id: id};
     var update = { 
        $set: {
        pd:"free" //Set subscription back to free    

            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 

    }


    //Delete University Information
    module.exports.deleteUniversity = function(id, callback){
    var query = {_id : id};
    Universities.remove(query, callback);

    }

    //Add Admission Offers
    module.exports.UpdateRecruitedStudents = function (id, student, options, callback) {
     var query =  {_id : id};
     var update = { 
        //$set: { 
        //$push: {  
        $addToSet:{
        admission_offers : {
        first_name:student.first_name,
        last_name:student.last_name,
        student_id:student.student_id,    
        email: student.email,
        university: student.university,
        country: student.country,
        phone: student.phone,
        course: student.course,
        application_status:student.application_status,
        live_status: student.live_status,
        academic_qualification: student.academic_qualification,
        language_proficiency:student.language_proficiency,
        travel_visa:student.travel_visa,
        date_of_activity:student.date_of_activity
        //recruit_date:student.recruit_date
            }
        }
        //} //End push  
       //} //End set        
        };  //End Update 

    Universities.findOneAndUpdate(query, update, options, callback);    


    }

    //Add Admission Offers
    module.exports.AddProcessedStudents = function (id, student, options, callback) {
     var query =  {_id : id};
     var update = { 
        //$set: { 
        //$push: {  
        $addToSet:{
        processed_students : {
        first_name:student.first_name,
        last_name:student.last_name,
        student_id:student.student_id,    
        email: student.email,
        university: student.university,
        country: student.country,
        phone: student.phone,
        course: student.course,
        application_status:student.application_status,
        live_status: student.live_status,
        academic_qualification: student.academic_qualification,
        language_proficiency:student.language_proficiency,
        travel_visa:student.travel_visa,
        date_of_activity:student.date_of_activity
        //recruit_date:student.recruit_date
            }
        }
        //} //End push  
       //} //End set        
        };  //End Update 

    Universities.findOneAndUpdate(query, update, options, callback);    


    }

    //Update Existing Student Information
    module.exports.updateUniversity = function(id, university, options, callback){
    var query = {_id : id};

    var update = { 
        $set: {
        first_name : university.name,
        last_name : university.email,
        email : university.university

            }//End Set          
        } //End Update        
    Universities.findOneAndUpdate(query, update, options, callback);

    }

    //Update Account Plan
    module.exports.updateUniversityPlan = function(id, plan, dateofsubscription, options, callback){
    var query = {_id : id};

    var update = { 
        $set: {
        pd : plan,
        sub_date: dateofsubscription   

            }//End Set          
        } //End Update        
    Universities.findOneAndUpdate(query, update, options, callback);

    }
    
    //Delete Recruited Students
    module.exports.deleteUniversityRecruitedstudent = function(id, studentid, options, callback){
    var studentid = {_id : studentid}; 
    var id = {_id: id};
     var update = { 
        $pull: {
        admission_offers : studentid

            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback);
    
        
    }
    
    //Delete Recruited Students
    module.exports.deleteUniversityMessagedstudent = function(id, studentid, options, callback){
    var studentid = {_id : studentid}; 
    var id = {_id: id};
     var update = { 
        $pull: {
        processed_students: studentid

            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback);
    
        
    }
    
    //Find by email
    module.exports.getUniversityByEmail = function(email, callback) {
     var query = {email:email};
     Universities.findOne(query,callback);    
    }

    
    //Activate by ID
    module.exports.activateAccount = function(university, options, callback) {
     var id = {_id: university._id};
     var update = { 
        $set: {
        activation : "activated"

            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 
        
    }
    
     //DeActivate by Email
    module.exports.deactivateAccount = function(id, options, callback) {
     var id = {_id: id};
     var update = { 
        $set: {
        activation : "notactivated"

            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 
        
    }

    
    //Verify by Email
    module.exports.verifyUniversityEmail = function(university, options, callback) {
     var id = {_id: university._id};
     var update = { 
        $set: {
        verification_status : "verified"

            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 
        
    }
    
    //Verify by Email
    module.exports.unVerifyUniversityEmail = function(id, options, callback) {
     var id = {_id: id};
     var update = { 
        $set: {
        verification_status : "no"

            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(id, update, options, callback); 
        
    }
    
    //Login
    //Find by username and Password
    module.exports.getUniversityByUsername = function(username, password, callback) {
     var query = {username: username, password:password};
     Universities.findOne(query,callback);    
    }



