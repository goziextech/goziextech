var mongoose = require ('mongoose');     
//Students Schema
var studentsSchema = mongoose.Schema({
    
    first_name: { type: String, 
                  required: true
                },
    last_name: { type: String, 
                  required: true
                },
    student_id: { type: String, 
                  required: false
                },
    email: { type: String, 
                  required: true
                },
    username: { type: String, 
                  required: false
                },
    password: { type: String, 
                  required: false
                },
    university: { type: String, 
                  required: true
                },
    country: { type: String, 
                  required: true
                },
    city: { type: String, 
                  required: false
                },
    state: { type: String, 
                  required: false
                },
    passport_no: { type: String, 
                  required: false
                },
    phone: { type: String, 
                  required: true
                },
    course: { type: String, 
                  required: true
                },
    application_status: { type: String, 
                  required: true
                },
    live_status: { type: String, 
                  required: false
                },
    academic_qualification: { type: String, 
                  required: true
                },
    language_proficiency: { type: String, 
                  required: true
                },
    travel_visa: { type: String, 
                  required: true
                },
    pd: { type: String, 
                  required: false
                },
    device: { type: String, 
                  required: false
                },
    about: { type: String, 
                  required: false
                },
    session: { type: String, 
                  required: false
                },
    degree_title: { type: String, 
                  required: false
                },
    universities_applied_to : [{
    
    university_name: { type: String, 
                  required: true
                },
    course_name: { type: String, 
                  required: false
                },
    processing_status: { type: String, 
                  required: false
                },     
    date_of_activity: { type: String, 
                  required: true
                },    
    create_date:{
        type: Date,
        default: Date.now
    }
		}],
    msg_txt : [{
    
    message: { type: String, 
                  required: false 
                },
    date_of_activity: { type: String, 
                  required: false 
                },    
    create_date:{
        type: Date,
        default: Date.now
    }
		}],
    time_of_activity: { type: String, 
                  required: true
                },
    date_of_activity: { type: String, 
                  required: false
                },
    create_date:{
        type: Date,
        default: Date.now
    }
                                     
});


var Students = module.exports = mongoose.model('Students',studentsSchema);


// Get All Students
module.exports.getStudents = function(callback,limit){
Students.find(callback).limit(limit); //declared in line 72   
    
}

// Get One Student by ID
module.exports.getStudentsById = function(id, callback){
Students.findById(id, callback);    
    
}


//Find by username and email
module.exports.getStudentsByEmail = function(email, callback) {
var query = {email:email};
Students.findOne(query,callback);    
}

//Find email
module.exports.CheckStatusByEmail = function(email, callback) {
var query = {$query: {email:email} };
//var order = ", $orderby: { create_date : -1 }";    
Students.findOne(query,callback).sort( { create_date: -1 } );    
}

//Add New student, create whatever was passed in and add it to the Student Database with Students SCHEMA
module.exports.addStudent = function(student,callback){
Students.create(student, callback);

}

//Delete Student Information
module.exports.deleteStudent = function(id, callback){
var query = {_id : id};
Students.remove(query, callback);

}

//Login
module.exports.getStudentByUsername = function(username, password, callback) {
 var query = {username: username, password:password};
 Students.findOne(query,callback);    
}

//compare password
//module.exports.comparePassword = function(password, callback) {
 //var query = {username: username};
// Students.findOne(query,callback);    
//}


/*

//Update Existing Student Information
module.exports.updateStudent = function(id, student, options, callback){
var query = {_id : id};
    
var update = {
    name : student.name,
    email : student.email,
    university : student.university,
    country : student.country
             
             };
Students.findOneAndUpdate(query, update, options, callback);

}


*/

