    var mongoose = require ('mongoose');

    //Universities Mailer Schema
    var universitiesmailerSchema = mongoose.Schema({

        first_name: { type: String, 
                      required: true
                    },
        last_name: { type: String, 
                      required: true
                    },
        email: { type: String, 
                      required: true
                    },
        username: { type: String, 
                      required: false
                    },
        password: { type: String, 
                      required: false
                    },
        pd: { type: String, 
                      required: false
                    },
        sub_date: { type: String, 
                      required: false
                    },
        trial: { type: Boolean, 
                      required: false
                    },
        device: { type: String, 
                      required: false
                    },
        about: { type: String, 
                      required: false
                    },
        session: { type: String, 
                      required: false //Check false and False for fields that are not required
                    },
        activation: { type: String, 
                      required: false //Check false and False for fields that are not required
                    },
        msg_txt : [{

        message: { type: String, 
                      required: false 
                    },
        date_of_activity: { type: String, 
                      required: false 
                    },    
        create_date:{
            type: Date,
            default: Date.now
        }
            }],
        date_of_activity: { type: String, 
                      required: false
                    },
        university: { type: String, 
                      required: false
                    },
        country: { type: String, 
                      required: false
                    },
        city: { type: String, 
                      required: false
                    },
        state: { type: String, 
                      required: false
                    },
        phone: { type: String, 
                      required: false
                    },
        courses : [{

        course_name: { type: String, 
                      required: false
                    },
        about_course: { type: String, 
                      required: false
                    },
        tuition: { type: String, 
                      required: false
                    },
        application_fee: { type: String, 
                      required: false
                    },
        application_requirement: { type: String, 
                      required: false
                    },
        application_deadline: { type: String, 
                      required: false
                    },
        create_date:{
            type: Date,
            default: Date.now
        }
            }],
        admission_offers : [{

        first_name: { type: String, 
                      required: true
                    },
        last_name: { type: String, 
                      required: true
                    },
        student_id:{ type: String, 
                      required: true
                    },    
        email: { type: String, 
                      required: true
                    },
        university: { type: String, 
                      required: true
                    },
        country: { type: String, 
                      required: true
                    },
        phone: { type: String, 
                      required: false
                    },
        course: { type: String, 
                      required: false
                    },
        application_status: { type: String, 
                      required: true
                    },
        live_status: { type: String, 
                      required: false
                    },
        academic_qualification: { type: String, 
                      required: false
                    },
        language_proficiency: { type: String, 
                      required: false
                    },
        travel_visa: { type: String, 
                      required: false
                    },
        date_of_activity: { type: String, 
                      required: false
                    },    
        create_date:{
            type: Date,
            default: Date.now
        }
            }],
        rejected_students : [{

        first_name: { type: String, 
                      required: true
                    },
        last_name: { type: String, 
                      required: true
                    },
        email: { type: String, 
                      required: true
                    },  
        university: { type: String, 
                      required: true
                    },
        country: { type: String, 
                      required: true
                    },
        phone: { type: String, 
                      required: true
                    },
        course: { type: String, 
                      required: false
                    },
        application_status: { type: String, 
                      required: false
                    },
        live_status: { type: String, 
                      required: false
                    },
        academic_qualification: { type: String, 
                      required: false
                    },
        language_proficiency: { type: String, 
                      required: false
                    },
        travel_visa: { type: String, 
                      required: false
                    },
        date_of_activity: { type: String, 
                      required: false
                    },    
        create_date:{
            type: Date,
            default: Date.now
        }
            }],
        verification_status : { type: String, 
                      required: false
                    },
        notification : { type: String, 
                      required: false
                    },
        processed_students: [{

        first_name: { type: String, 
                      required: true
                    },
        last_name: { type: String, 
                      required: true
                    },
        student_id:{ type: String, 
                      required: true
                    },     
        email: { type: String, 
                      required: true
                    },  
        university: { type: String, 
                      required: true
                    },
        country: { type: String, 
                      required: true
                    },
        phone: { type: String, 
                      required: true
                    },
        course: { type: String, 
                      required: false
                    },
        application_status: { type: String, 
                      required: false
                    },
        live_status: { type: String, 
                      required: false
                    },
        academic_qualification: { type: String, 
                      required: false
                    },
        language_proficiency: { type: String, 
                      required: false
                    },
        travel_visa: { type: String, 
                      required: false
                    },
        date_of_activity: { type: String, 
                      required: false
                    },    
        create_date:{
            type: Date,
            default: Date.now
        }
            }],
        image_url : { type: String, 
                      required: false
                    },
        university_website : { type: String, 
                      required: false
                    },
        application_portal : { type: String, 
                      required: false
                    },
        create_date:{
            type: Date,
            default: Date.now
        }

    });


    var universitymaillist = module.exports = mongoose.model('universitymaillist', universitiesmailerSchema);


    // Get Universities Mail info
    module.exports.getUniversitiesMailInfo = function(callback,limit){
    universitymaillist.find(callback).limit(limit);    

    }
    
    //Find by username and email
    module.exports.getUniversityMailInfoByEmail = function(email, callback) {
     var query = {email:email};
     Universities.findOne(query,callback);    
    }
    
     //Add New university Mail info
    module.exports.addUniversityMailInfo = function(university,callback){
    universitymaillist.create(university, callback);

    }
    
    
     //Add New university Mail info
    module.exports.readdUniversityMailInfo = function(subscriptiondetails,callback){
    universitymaillist.create(subscriptiondetails, callback);

    } 
    
    //Delete University Information
    module.exports.unsubscribeUniversity = function(university, callback){
    var query = {email : university.email};
    universitymaillist.remove(query, callback);

    }
    
    //Delete University Information on email change by email
    module.exports.unsubscribeUniversityOnEmailChange = function(olduniversityemail, callback){
    var query = {email : olduniversityemail};
    universitymaillist.remove(query, callback);

    }
    
     // Edit University Subscription Mail
    module.exports.EditUniversitySubscriptionMail = function(oldemailaddress, universityemail, options, callback){
     var oldemailaddress = {email: oldemailaddress}; //Mongodb sytax
     var update = { 
        $set: {
        email : universityemail
            }//End Set          
        } //End Update    
     Universities.findOneAndUpdate(oldemailaddress, update, options, callback); 

    }
    
     //Delete University Information
    module.exports.unsubscribeUniversitybyId = function(id, callback){
    var query = {_id : id};
    universitymaillist.remove(query, callback);

    }